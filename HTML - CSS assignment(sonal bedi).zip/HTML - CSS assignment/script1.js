function tosubmit() {
    if (localStorage.getItem("pname")) {
        PRODUCTNAME = eval(localStorage.getItem("PRODUCT NAME"));
        UNITOFMEASUREMENT = eval(localStorage.getItem("UNIT OF MEASUREMENT"));
        PRICE = eval(localStorage.getItem("PRICE"));
        PRODUCTDESCRIPTION = eval(localStorage.getItem("PRODUCT DESCRIPTION"));
        id = eval(localStorage.getItem("id"));
    }

    i = PRODUCTNAME.length;
    PRODUCTNAME[i] = document.getElementById("PRODUCT NAME").value;
    UNITOFMEASUREMENT[i] = document.getElementById("UNIT OF MEASUREMENT").value;
    PRICE[i] = document.getElementById("PRICE").value;

    description[i] = document.getElementById("DESCRIPTION").value;
    id[i] = i;
    localStorage.setItem("PRODUCT NAME", JSON.stringify(pname));
    localStorage.setItem("UNIT OF MEASUREMENT", JSON.stringify(unit));
    localStorage.setItem("PRICE", JSON.stringify(price));
    localStorage.setItem("DESCRIPTION", JSON.stringify(description));
    localStorage.setItem("id", JSON.stringify(id));
}

function init() {

    var PRODUCTNAME = eval(localStorage.getItem("PRODUCT NAME"));
    var UNITOFMEASUREMENT = eval(localStorage.getItem("UNIT OF MEASUREMENT"));
    var PRICE = eval(localStorage.getItem("PRICE"));
    var PRODUCTDESCRIPTION = eval(localStorage.getItem("PRODUCT DESCRIPTION"));
    var id = eval(localStorage.getItem("id"));

    var table = document.getElementById("table");
    for (j = 0; j < PRODUCTNAME.length; j++) {
        var row = table.insertRow();
        row.innerHTML = "<td>" + id[j] + "</td>" + "<td>" + PRODUCTNAME[j] + "</td>" + "<td>" + PRODUCTDESCRIPTION[j] + "</td>" + "< td > " + PRICE[j] + "</td > " + " < td > " + UNITOFMEASUREMENT[j] + "</td > " + " < td > " + " < button onclick = edit(" + id[j] + ");> " + "Edit" + "</button > " + "</td > " + " < td > " + " < button onclick = del(" + id[j] + ");> " + "Delete" + "</button > " + "</td > ";
    }
}
